from flask import Flask, request
from main import place_order

app = Flask(__name__)

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json()
    if not data or "action" not in data:
        return {"status": "error", "message": "No action provided"}, 400

    action = data["action"]
    if action not in ["buy", "sell"]:
        return {"status": "error", "message": "Invalid action"}, 400

    place_order(action)
    return {"status": "success", "message": f"Executed {action}"}, 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)