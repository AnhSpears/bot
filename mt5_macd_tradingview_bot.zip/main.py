import json
import telebot
import MetaTrader5 as mt5

# Load config
with open("config.json") as f:
    config = json.load(f)

bot = telebot.TeleBot(config["telegram_token"])
SYMBOL = config["symbol"]
LOT = config["lot"]

# Init MT5
mt5.initialize()

def place_order(action):
    price = mt5.symbol_info_tick(SYMBOL).ask if action == "buy" else mt5.symbol_info_tick(SYMBOL).bid
    order_type = mt5.ORDER_TYPE_BUY if action == "buy" else mt5.ORDER_TYPE_SELL

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": LOT,
        "type": order_type,
        "price": price,
        "deviation": 10,
        "magic": 123456,
        "comment": "Auto trade by webhook",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    result = mt5.order_send(request)
    bot.send_message(config["telegram_chat_id"], f"✅ {action.upper()} {SYMBOL} | price: {price}\nResult: {result.comment}")